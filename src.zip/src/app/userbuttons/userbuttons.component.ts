import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userbuttons',
  templateUrl: './userbuttons.component.html',
  styleUrls: ['./userbuttons.component.css']
})
export class UserbuttonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
