import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import {MentorLandingComponent} from './mentor-landing/mentor-landing.component';
import { EditskillsComponent } from './editskills/editskills.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';



const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent  },
  { path: 'signup', component: SignupComponent },
  { path: 'adminhome', component: AdminhomeComponent },
    { path: 'user-landing', component: UserLandingComponent  },
    { path: 'mentor-landing', component: MentorLandingComponent  },
    { path: 'editskills', component: EditskillsComponent  },
    
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
