import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminbuttons',
  templateUrl: './adminbuttons.component.html',
  styleUrls: ['./adminbuttons.component.css']
})
export class AdminbuttonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
