import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signupnav',
  templateUrl: './signupnav.component.html',
  styleUrls: ['./signupnav.component.css']
})
export class SignupnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
