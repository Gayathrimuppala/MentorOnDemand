package com.project.MentorOnDemand.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "training")

public class Trainings {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

@Column(name = "user_id")
private Long userId;

@Column(name = "mentor_id")
private Long mentorId;

@Column(name = "skill_id")
private Long skillId;

@Column(name = "status")
private String status;

@Column(name = "progress")
private String progress;

@Column(name = "rating")
private Float rating;

@Column(name = "start_date")
private Date startDate;

@Column(name = "end_date")
private Date endDate;

@Column(name = "start_time")
private Time startTime;

@Column(name = "end_time")
private Time endTime;

@Column(name = "amount_received")
private Float amountReceived;

public Trainings() {
}

public Trainings(long id, Long userId, Long mentorId, Long skillId, String status, String progress, Float rating,
		Date startDate, Date endDate, Time startTime, Time endTime, Float amountReceived) {
	super();
	this.id = id;
	this.userId = userId;
	this.mentorId = mentorId;
	this.skillId = skillId;
	this.status = status;
	this.progress = progress;
	this.rating = rating;
	this.startDate = startDate;
	this.endDate = endDate;
	this.startTime = startTime;
	this.endTime = endTime;
	this.amountReceived = amountReceived;
}

public long getId() {
	return id;
}

public Long getUserId() {
	return userId;
}

public void setUserId(Long userId) {
	this.userId = userId;
}

public Long getMentorId() {
	return mentorId;
}

public void setMentorId(Long mentorId) {
	this.mentorId = mentorId;
}

public Long getSkillId() {
	return skillId;
}

public void setSkillId(Long skillId) {
	this.skillId = skillId;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getProgress() {
	return progress;
}

public void setProgress(String progress) {
	this.progress = progress;
}

public Float getRating() {
	return rating;
}

public void setRating(Float rating) {
	this.rating = rating;
}

public Date getStartDate() {
	return startDate;
}

public void setStartDate(Date startDate) {
	this.startDate = startDate;
}

public Date getEndDate() {
	return endDate;
}

public void setEndDate(Date endDate) {
	this.endDate = endDate;
}

public Time getStartTime() {
	return startTime;
}

public void setStartTime(Time startTime) {
	this.startTime = startTime;
}

public Time getEndTime() {
	return endTime;
}

public void setEndTime(Time endTime) {
	this.endTime = endTime;
}

public Float getAmountReceived() {
	return amountReceived;
}

public void setAmountReceived(Float amountReceived) {
	this.amountReceived = amountReceived;
}

@Override
public String toString() {
	return "Trainings [id=" + id + ", userId=" + userId + ", mentorId=" + mentorId + ", skillId=" + skillId
			+ ", status=" + status + ", progress=" + progress + ", rating=" + rating + ", startDate=" + startDate
			+ ", endDate=" + endDate + ", startTime=" + startTime + ", endTime=" + endTime + ", amountReceived="
			+ amountReceived + "]";
}

}
