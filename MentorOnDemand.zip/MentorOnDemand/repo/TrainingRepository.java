package com.project.MentorOnDemand.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.project.MentorOnDemand.model.Trainings;

public interface TrainingRepository extends JpaRepository<Trainings, String> {

	List<Trainings> findAll();
	
}
