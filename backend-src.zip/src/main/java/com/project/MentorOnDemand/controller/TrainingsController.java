package com.project.MentorOnDemand.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.MentorOnDemand.model.Trainings;
import com.project.MentorOnDemand.repo.TrainingsRepository;


@CrossOrigin(origins = "*")
@RestController
public class TrainingsController {
       
       @Autowired
       TrainingsRepository repository;
       
       @GetMapping(path="/trainings")
       public List<Trainings> getAllTrainings() {
              System.out.println("Get all trainings...");
        
              List<Trainings> trainings = new ArrayList<>();
              
              repository.findAll().forEach(trainings::add);

              return trainings;
       }
       
       @GetMapping(value = "/getTrainingDetails/id/{id}")
   	public Optional<Trainings> findById(@PathVariable long id) {

   		Optional<Trainings> trainings = repository.findById(id);
   		return trainings;
   	}
       
       @PostMapping(value = "/trainings/create")
   	public Trainings postTraining(@RequestBody Trainings trainings) {

   		Trainings training = repository.save(new Trainings(trainings.getId(), trainings.getUserId(), trainings.getMentorId(),trainings.getSkillId(),
   				trainings.getStatus(),trainings.getProgress(),trainings.getRating(),trainings.getStartDate(),
   				trainings.getEndDate(),trainings.getStartTime(),trainings.getEndTime(),trainings.getAmountReceived()));
   		
   		return training;
   	}
       
       @GetMapping(path="/propose/{id}")
       public ResponseEntity<Trainings> updateTrainings(@PathVariable("id") long id, @RequestBody Trainings training) {
              
              System.out.println("inside propose");
              System.out.println("Update Trainings with id = " + id + "...");

              Optional<Trainings> tdata = repository.findById(id);

              if (tdata.isPresent()) {
                     Trainings trainings = tdata.get();
                     trainings.setStatus("proposed");
                     return new ResponseEntity<>(repository.save(trainings), HttpStatus.OK);
              } else {
                     return new ResponseEntity<>(HttpStatus.NOT_FOUND);
              }
       }

@GetMapping(path="/approve/{id}")
public ResponseEntity<Trainings> updateTrainingStatus(@PathVariable("id") long id, @RequestBody Trainings training) {
       System.out.println("inside approve");
       System.out.println("Update Trainings with ID = " + id + "...");

       Optional<Trainings> tdata = repository.findById(id);

       if (tdata.isPresent()) {
              Trainings trainings = tdata.get();
              trainings.setStatus("approved");
              return new ResponseEntity<>(repository.save(trainings), HttpStatus.OK);
       } else {
              return new ResponseEntity<>(HttpStatus.NOT_FOUND);
       }
}      
@GetMapping("/getCompletedTrainings")
public List<Trainings> getCompletedTrainings() {
       
    
       List<Trainings> trainings = new ArrayList<>();
       
      // trainingrepo.findCompletedTrainings("completed");

       return trainings;
}


}
