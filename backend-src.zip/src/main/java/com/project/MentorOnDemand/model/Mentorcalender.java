package com.project.MentorOnDemand.model;


import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentorcalender")
public class Mentorcalender {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "mid")
	private Long mid;
	
	@Column(name = "starttime")
	private String starttime;
	
	@Column(name = "endtime")
	private String endtime;
	
	@Column(name = "startdate")
	private Date startdate;
	
	@Column(name = "enddate")
	private Date enddate;

	public Mentorcalender() {
		
	}

	public Mentorcalender(Long mid, String starttime, String endtime, Date startdate, Date enddate) {
		this.mid = mid;
		this.starttime = starttime;
		this.endtime = endtime;
		this.startdate = startdate;
		this.enddate = enddate;
	}

	public long getId() {
		return id;
	}

	

	public Long getMid() {
		return mid;
	}

	public void setMid(Long mid) {
		this.mid = mid;
	}

	public String getStarttime() {
		return starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	@Override
	public String toString() {
		return "Mentorcalender [id=" + id + ", mid=" + mid + ", starttime=" + starttime + ", endtime=" + endtime
				+ ", startdate=" + startdate + ", enddate=" + enddate + "]";
	}
	
	
	
	}


