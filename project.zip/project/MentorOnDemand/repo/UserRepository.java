package com.project.MentorOnDemand.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


import com.project.MentorOnDemand.model.User;

public interface UserRepository extends CrudRepository<User, Long>
{

	List<User> findAll();
	List<User> findById(long id);
}
