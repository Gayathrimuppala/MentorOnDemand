package com.project.MentorOnDemand.model;

public class TrainingsModel {
	private long id;

	private int userid;

	private String mentor_username;

	private String status;
	
	private int progress;

	public TrainingsModel(){
		
	}
	
	
	public TrainingsModel(long id, int userid, String mentor_username, String status, int progress) {
		super();
		this.id = id;
		this.userid = userid;
		this.mentor_username = mentor_username;
		this.status = status;
		this.progress = progress;
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getMentor_username() {
		return mentor_username;
	}

	public void setMentor_username(String mentor_username) {
		this.mentor_username = mentor_username;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	@Override
	public String toString() {
		return "TraningsModel [id=" + id + ", userid=" + userid + ", mentor_username=" + mentor_username + ", status="
				+ status + ", progress=" + progress + "]";
	}
	
}
