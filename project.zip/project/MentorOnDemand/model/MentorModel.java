package com.project.MentorOnDemand.model;

public class MentorModel
{
	private long id;

	private String username;

	private String skill_name;
	
	private String duration;
	
	private String linkedinurl;
	
	private int experience;
	
	private Boolean active;
	
	private long skill_id;

	public MentorModel(long id, String username, String skill_name, String duration, String linkedinurl, int experience,
			Boolean active, long skill_id) {
		super();
		this.id = id;
		this.username = username;
		this.skill_name = skill_name;
		this.duration = duration;
		this.linkedinurl = linkedinurl;
		this.experience = experience;
		this.active = active;
		this.skill_id = skill_id;
	}

	public MentorModel() {
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getSkillName() {
		return skill_name;
	}

	public void setName(String skill_name) {
		this.skill_name = skill_name;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getLinkedinurl() {
		return linkedinurl;
	}

	public void setLinkedinurl(String linkedinurl) {
		this.linkedinurl = linkedinurl;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public long getSkillId() {
		return skill_id;
	}

	public void setSkillId(long skill_id) {
		this.skill_id = skill_id;
	}

	@Override
	public String toString() {
		return "MentorModel [id=" + id + ", username=" + username + ", skill_name=" + skill_name + ", duration=" + duration
				+ ", linkedinurl=" + linkedinurl + ", experience=" + experience + ", active=" + active + ", skill_id="
				+ skill_id + "]";
	}
	

	
}
