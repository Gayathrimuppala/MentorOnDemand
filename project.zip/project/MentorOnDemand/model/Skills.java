package com.project.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "skills")
public class Skills {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	

	@Column(name = "name")
	private String name;
	
	@Column(name = "toc")
	private String toc;
	
	@Column(name = "duration")
	private String duration;
	
	@Column(name = "prerequisites")
	private String prerequisites;

	public Skills() {
		
	}

	public Skills(String name, String toc, String duration, String prerequisites) {
		
		this.name = name;
		this.toc = toc;
		this.duration = duration;
		this.prerequisites = prerequisites;
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getToc() {
		return toc;
	}

	public void setToc(String toc) {
		this.toc = toc;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getPrerequisites() {
		return prerequisites;
	}

	public void setPrerequisites(String prerequisites) {
		this.prerequisites = prerequisites;
	}

	@Override
	public String toString() {
		return "Technologies [id=" + id + ", name=" + name + ", toc=" + toc + ", duration=" + duration
				+ ", prerequisites=" + prerequisites + "]";
	}
	
	
}
