package com.project.MentorOnDemand.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.MentorOnDemand.model.Mentor;
import com.project.MentorOnDemand.model.Trainings;
import com.project.MentorOnDemand.model.TrainingsModel;
import com.project.MentorOnDemand.repo.TrainingsRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class TrainingsController {

/*	@Autowired
	TrainingsRepository repository;
	TrainingsRepository mrepository;
	
	@GetMapping("/trainings")
	public List<Trainings> getAllTrainings() {
		System.out.println("Get all trainings...");

		List<Trainings> trainings = new ArrayList<>();
		repository.findAll().forEach(trainings::add);

		return trainings;
	}
	
	@PostMapping(value = "/trainings/create")
	public Trainings postTraining(@RequestBody Trainings trainings) {

		Trainings training = repository.save(new Trainings(trainings.getId(), trainings.getUserId(), trainings.getMentorId(),trainings.getSkillId(),
				trainings.getStatus(),trainings.getProgress(),trainings.getRating(),trainings.getStartDate(),
				trainings.getEndDate(),trainings.getStartTime(),trainings.getEndTime(),trainings.getAmountReceived()));
		
		return training;
	}
	
	@GetMapping(value = "/getTrainingDetails/userid/{userid}")
	public List<Trainings> findByUserId(@PathVariable int userid) {

		List<Trainings> trainings = repository.findByUserId(userid);
		return trainings;
	}
	
	@GetMapping(value = "/getTrainingDetails/id/{id}")
	public List<Trainings> findById(@PathVariable long id) {

		List<Trainings> trainings = repository.findById(id);
		return trainings;
	}
	/*@GetMapping("/getCompletedTrainings")
	List<TrainingsModel> getCompletedTrainings()
	{
		List<Trainings> trainings_list = repository.findByStatusAndUserId("completed", 1);
		List<TrainingsModel> trainingsm_list = new ArrayList<TrainingsModel>();
		for(Trainings trainings:trainings_list)
		{
			int mentor_id = trainings.getMentorId();
			Optional<Mentor> mentor = mrepository.findById((long) mentor_id);
			
			//(long id, int userid, String mentor_username, int status, int progress)
			TrainingsModel tmodel = new TrainingsModel(trainings.getId(),
					trainings.getUserId(), mentor.get().getUsername(), trainings.getStatus(),
					trainings.getProgress());
			
			trainingsm_list.add(tmodel);
		}
		
		return trainingsm_list;
	}*/
	
}
