package com.project.MentorOnDemand.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import com.project.MentorOnDemand.model.User;
import com.project.MentorOnDemand.repo.UserRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserController 
{

	@Autowired
	UserRepository repository;
	
	@GetMapping("/users")
	public List<User> getAllUsers() {
		System.out.println("Get all Users...");

		List<User> user = new ArrayList<>();
		repository.findAll().forEach(user::add);

		return user;
	}
	
	@GetMapping("/users/id/{id}")
	public List<User> findById(@PathVariable long id) {

		List<User> user = repository.findById(id);
		return user;
	}
}
