package com.project.MentorOnDemand.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentor")
public class Mentor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "username")
	private String username;
	
	@Column(name = "linkedinurl")
	private String linkedinurl;
	
	@Column(name = "regdate")
	private Date regdate;
	
	@Column(name = "regcode")
	private String regcode;
	
	@Column(name = "experience")
	private int experience;
	
	@Column(name = "active")
	private Boolean active;

	public Mentor() {
		
	}

	public Mentor(String username, String linkedinurl, Date regdate, String regcode, int experience,
			Boolean active) {

		this.username = username;
		this.linkedinurl = linkedinurl;
		this.regdate = regdate;
		this.regcode = regcode;
		this.experience = experience;
		this.active = active;
	}

	public long getId() {
		return id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLinkedinurl() {
		return linkedinurl;
	}

	public void setLinkedinurl(String linkedinurl) {
		this.linkedinurl = linkedinurl;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public String getRegcode() {
		return regcode;
	}

	public void setRegcode(String regcode) {
		this.regcode = regcode;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Mentor [id=" + id + ", username=" + username + ", linkedinurl=" + linkedinurl + ", regdate=" + regdate
				+ ", regcode=" + regcode + ", experience=" + experience + ", active=" + active + "]";
	}

}
