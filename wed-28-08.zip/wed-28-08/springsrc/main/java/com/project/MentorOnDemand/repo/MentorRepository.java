package com.project.MentorOnDemand.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.project.MentorOnDemand.model.Mentor;
import com.project.MentorOnDemand.model.Skills;

public interface MentorRepository extends CrudRepository<Mentor, Long>{

	List<Mentor> findById(long id);

	//List<Skills> findBySkillName(String  name);

	//List<Skills> findByName(String name);
}
