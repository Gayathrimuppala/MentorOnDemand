package com.project.MentorOnDemand.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.project.MentorOnDemand.model.Mentor;
import com.project.MentorOnDemand.model.MentorModel;
import com.project.MentorOnDemand.model.Skills;
import com.project.MentorOnDemand.repo.MentorRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class MentorController {

	@Autowired
	MentorRepository repository;
	
	@GetMapping(value = "/getMentorDetails/id/{id}")
	public List<Mentor> findById(@PathVariable long id) {

		List<Mentor> mentor = repository.findById(id);
		return mentor;
	}
	
	/*@GetMapping("/getSearchResults")
	List<MentorModel> getSearchResults()
	{
		List<Skills> s_list = repository.findBySkillName("skill_name");
		List<MentorModel> m_list = new ArrayList<MentorModel>();
		for(Skills skills:s_list)
		{
			String skill_name=skills.getName();
			Optional<Mentor> mentor = repository.findById((long) mentor_id);
		}
	}
	*/
	
}
