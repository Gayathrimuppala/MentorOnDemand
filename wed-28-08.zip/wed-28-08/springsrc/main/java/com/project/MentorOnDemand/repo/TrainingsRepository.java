package com.project.MentorOnDemand.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.project.MentorOnDemand.model.Trainings;

public interface TrainingsRepository extends CrudRepository<Trainings,Long>
{

	
	/*@Query("Select t From Tranings t where t.status = :status and t.userid = :userid")
	List<Trainings> findByStatusAndUserId(@Param("status") String status,@Param("userid") int userid);*/
	Optional<Trainings> findById(long id);

	List<Trainings> findByUserId(int userid);

	void getById(long id);
	
}
