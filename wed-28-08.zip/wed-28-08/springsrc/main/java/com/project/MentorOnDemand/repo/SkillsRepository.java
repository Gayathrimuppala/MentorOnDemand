package com.project.MentorOnDemand.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.project.MentorOnDemand.model.Skills;

public interface SkillsRepository extends CrudRepository<Skills, Long>{

	List<Skills> findAll();

	List<Skills> findById(long id);

	List<Skills> findByName(String name);

}
