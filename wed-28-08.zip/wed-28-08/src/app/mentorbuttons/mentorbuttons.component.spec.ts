import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorbuttonsComponent } from './mentorbuttons.component';

describe('MentorbuttonsComponent', () => {
  let component: MentorbuttonsComponent;
  let fixture: ComponentFixture<MentorbuttonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorbuttonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorbuttonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
