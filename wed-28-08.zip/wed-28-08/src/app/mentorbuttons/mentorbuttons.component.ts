import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorbuttons',
  templateUrl: './mentorbuttons.component.html',
  styleUrls: ['./mentorbuttons.component.css']
})
export class MentorbuttonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
