import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginnav',
  templateUrl: './loginnav.component.html',
  styleUrls: ['./loginnav.component.css']
})
export class LoginnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
