import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import {MentorLandingComponent} from './mentor-landing/mentor-landing.component';
import { EditskillsComponent } from './editskills/editskills.component';


const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent  },
    { path: 'user-landing', component: UserLandingComponent  },
    { path: 'mentor-landing', component: MentorLandingComponent  },
    { path: 'editskills', component: EditskillsComponent  },
    
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
