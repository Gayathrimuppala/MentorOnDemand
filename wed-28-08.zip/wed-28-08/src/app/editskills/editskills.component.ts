import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editskills',
  templateUrl: './editskills.component.html',
  styleUrls: ['./editskills.component.css']
})
export class EditskillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
