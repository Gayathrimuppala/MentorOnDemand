import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';
import { EditskillsComponent } from './editskills/editskills.component';
import { MentorbuttonsComponent } from './mentorbuttons/mentorbuttons.component';
import { UserbuttonsComponent } from './userbuttons/userbuttons.component';
import { LoginComponent } from './login/login.component';
import { LoginnavComponent } from './loginnav/loginnav.component';
import { SignupComponent } from './signup/signup.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    UserLandingComponent,
    MentorLandingComponent,
    EditskillsComponent,
    MentorbuttonsComponent,
    UserbuttonsComponent,
    LoginComponent,
    LoginnavComponent,
    SignupComponent,
    AdminhomeComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
