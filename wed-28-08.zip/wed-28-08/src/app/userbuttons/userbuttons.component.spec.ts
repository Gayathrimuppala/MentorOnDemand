import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserbuttonsComponent } from './userbuttons.component';

describe('UserbuttonsComponent', () => {
  let component: UserbuttonsComponent;
  let fixture: ComponentFixture<UserbuttonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserbuttonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserbuttonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
